# Workout API — Desafio DIO

API REST desenvolvida com **FastAPI**, **SQLAlchemy** e **SQLite** para gerenciar atletas, categorias e centros de treinamento.

O projeto implementa os requisitos do desafio:
- Query parameters `nome` e `cpf` no endpoint de atletas.
- Resposta customizada da listagem de atletas com `nome`, `centro_treinamento` e `categoria`.
- Tratamento de `sqlalchemy.exc.IntegrityError` no cadastro, com HTTP 303 e mensagem específica para CPF duplicado.
- Paginação com `fastapi-pagination`, usando `limit` e `offset`.

## Tecnologias
- Python 3.11+
- FastAPI
- SQLAlchemy 2
- SQLite
- fastapi-pagination

SQLite foi escolhido para facilitar a execução local: não exige Docker nem instalação de servidor de banco. O arquivo `workout_api.db` é criado automaticamente.

## Como executar no Windows (PowerShell / VS Code)

Abra a pasta do projeto no VS Code e execute no terminal:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
uvicorn workout_api.main:app --reload
```

Se o PowerShell bloquear a ativação do ambiente, libere apenas na sessão atual:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```

Depois repita a ativação.

Acesse:
- API: http://127.0.0.1:8000
- Swagger: http://127.0.0.1:8000/docs

## Endpoints

| Método | Rota | Descrição |
|---|---|---|
| GET | `/` | Verifica se a API está ativa |
| POST | `/categorias` | Cadastra categoria |
| GET | `/categorias` | Lista categorias |
| POST | `/centros-treinamento` | Cadastra centro de treinamento |
| GET | `/centros-treinamento` | Lista centros |
| POST | `/atletas` | Cadastra atleta |
| GET | `/atletas` | Lista atletas com filtros e paginação |
| GET | `/atletas/{atleta_id}` | Consulta atleta |
| DELETE | `/atletas/{atleta_id}` | Exclui atleta |

## Exemplos para Postman

### 1. Criar categoria
`POST http://127.0.0.1:8000/categorias`

```json
{ "nome": "Scale" }
```

### 2. Criar centro de treinamento
`POST http://127.0.0.1:8000/centros-treinamento`

```json
{
  "nome": "CT Central",
  "endereco": "Rua das Flores, 100",
  "proprietario": "Maria Silva"
}
```

### 3. Criar atleta
Use os IDs numéricos (`pk_id`) retornados nas respostas de categoria e centro:

`POST http://127.0.0.1:8000/atletas`

```json
{
  "nome": "Miguel Gonzalez",
  "cpf": "12345678901",
  "idade": 22,
  "peso": 75.5,
  "altura": 1.78,
  "sexo": "M",
  "centro_treinamento_id": 1,
  "categoria_id": 1
}
```

O CPF é armazenado sem pontuação e deve conter 11 dígitos. Use dados fictícios nos testes.

### 4. Listar atletas
`GET http://127.0.0.1:8000/atletas?limit=10&offset=0`

Filtros:
- `?nome=mi`
- `?cpf=12345678901`
- `?nome=mi&cpf=12345678901&limit=10&offset=0`

A listagem retorna os campos `id`, `nome`, `centro_treinamento` e `categoria`, dentro do envelope `items`, `total`, `limit` e `offset` do fastapi-pagination.

### Tratamento de CPF duplicado
Ao tentar cadastrar outro atleta com o mesmo CPF, a API responde HTTP `303` com detalhe semelhante a:

```json
{
  "detail": "Já existe um atleta cadastrado com o cpf: 12345678901"
}
```

## Estrutura

```text
workout_api_dio/
├── workout_api/
│   ├── routers/
│   │   ├── atletas.py
│   │   ├── categorias.py
│   │   └── centros_treinamento.py
│   ├── database.py
│   ├── main.py
│   ├── models.py
│   └── schemas.py
├── .gitignore
├── README.md
└── requirements.txt
```

## Publicar no GitHub

Crie um repositório vazio no GitHub. Na pasta do projeto, use:

```bash
git init
git add .
git commit -m "feat: implementa Workout API do desafio DIO"
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/SEU-REPOSITORIO.git
git push -u origin main
```
