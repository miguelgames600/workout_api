import uuid
from sqlalchemy import ForeignKey, Integer, String, Float
from sqlalchemy.orm import Mapped, mapped_column, relationship
from .database import Base


class Categoria(Base):
    __tablename__ = "categoria"

    pk_id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    id: Mapped[str] = mapped_column(String(36), unique=True, default=lambda: str(uuid.uuid4()), index=True)
    nome: Mapped[str] = mapped_column(String(40), unique=True, nullable=False)

    atletas: Mapped[list["Atleta"]] = relationship(back_populates="categoria")


class CentroTreinamento(Base):
    __tablename__ = "centro_treinamento"

    pk_id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    id: Mapped[str] = mapped_column(String(36), unique=True, default=lambda: str(uuid.uuid4()), index=True)
    nome: Mapped[str] = mapped_column(String(20), unique=True, nullable=False)
    endereco: Mapped[str] = mapped_column(String(60), nullable=False)
    proprietario: Mapped[str] = mapped_column(String(30), nullable=False)

    atletas: Mapped[list["Atleta"]] = relationship(back_populates="centro_treinamento")


class Atleta(Base):
    __tablename__ = "atleta"

    pk_id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    id: Mapped[str] = mapped_column(String(36), unique=True, default=lambda: str(uuid.uuid4()), index=True)
    nome: Mapped[str] = mapped_column(String(50), nullable=False, index=True)
    cpf: Mapped[str] = mapped_column(String(11), unique=True, nullable=False, index=True)
    idade: Mapped[int] = mapped_column(Integer, nullable=False)
    peso: Mapped[float] = mapped_column(Float(precision=2), nullable=False)
    altura: Mapped[float] = mapped_column(Float(precision=2), nullable=False)
    sexo: Mapped[str] = mapped_column(String(1), nullable=False)
    centro_treinamento_id: Mapped[int] = mapped_column(ForeignKey("centro_treinamento.pk_id"), nullable=False)
    categoria_id: Mapped[int] = mapped_column(ForeignKey("categoria.pk_id"), nullable=False)

    centro_treinamento: Mapped["CentroTreinamento"] = relationship(back_populates="atletas")
    categoria: Mapped["Categoria"] = relationship(back_populates="atletas")
