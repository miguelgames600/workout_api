from fastapi import FastAPI
from fastapi_pagination import add_pagination
from .database import Base, engine
from .routers import atletas, categorias, centros_treinamento

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Workout API",
    description="API para gerenciamento de atletas, categorias e centros de treinamento.",
    version="1.0.0",
)

app.include_router(atletas.router)
app.include_router(categorias.router)
app.include_router(centros_treinamento.router)
add_pagination(app)


@app.get("/", tags=["Health"])
def health_check():
    return {"message": "Workout API funcionando!"}
