from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session
from ..database import get_db
from .. import models, schemas

router = APIRouter(prefix="/categorias", tags=["Categorias"])


@router.post("", response_model=schemas.CategoriaOut, status_code=status.HTTP_201_CREATED)
def criar_categoria(payload: schemas.CategoriaCreate, db: Session = Depends(get_db)):
    item = models.Categoria(**payload.model_dump())
    db.add(item)
    try:
        db.commit()
        db.refresh(item)
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=303, detail="Já existe uma categoria com esses dados.")
    return item


@router.get("", response_model=list[schemas.CategoriaOut])
def listar_categorias(db: Session = Depends(get_db)):
    return db.query(models.Categoria).order_by(models.Categoria.pk_id).all()
