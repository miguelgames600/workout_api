from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session
from ..database import get_db
from .. import models, schemas

router = APIRouter(prefix="/centros-treinamento", tags=["Centros de treinamento"])


@router.post("", response_model=schemas.CentroTreinamentoOut, status_code=status.HTTP_201_CREATED)
def criar_centro(payload: schemas.CentroTreinamentoCreate, db: Session = Depends(get_db)):
    item = models.CentroTreinamento(**payload.model_dump())
    db.add(item)
    try:
        db.commit()
        db.refresh(item)
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=303, detail="Já existe um centro de treinamento com esses dados.")
    return item


@router.get("", response_model=list[schemas.CentroTreinamentoOut])
def listar_centros(db: Session = Depends(get_db)):
    return db.query(models.CentroTreinamento).order_by(models.CentroTreinamento.pk_id).all()
