from fastapi import APIRouter, Depends, HTTPException, Query, status
from fastapi_pagination import LimitOffsetPage, LimitOffsetParams
from fastapi_pagination.ext.sqlalchemy import paginate
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session, joinedload
from ..database import get_db
from .. import models, schemas

router = APIRouter(prefix="/atletas", tags=["Atletas"])


@router.post("", response_model=schemas.AtletaOut, status_code=status.HTTP_201_CREATED)
def criar_atleta(payload: schemas.AtletaCreate, db: Session = Depends(get_db)):
    atleta = models.Atleta(**payload.model_dump())
    db.add(atleta)
    try:
        db.commit()
        db.refresh(atleta)
    except IntegrityError:
        db.rollback()
        raise HTTPException(
            status_code=303,
            detail=f"Já existe um atleta cadastrado com o cpf: {payload.cpf}",
        )
    return (
        db.query(models.Atleta)
        .options(joinedload(models.Atleta.categoria), joinedload(models.Atleta.centro_treinamento))
        .filter(models.Atleta.pk_id == atleta.pk_id)
        .first()
    )


@router.get("", response_model=LimitOffsetPage[schemas.AtletaListItem])
def listar_atletas(
    nome: str | None = Query(default=None, description="Filtra pelo nome do atleta"),
    cpf: str | None = Query(default=None, min_length=11, max_length=11, description="Filtra pelo CPF (11 números)"),
    params: LimitOffsetParams = Depends(),
    db: Session = Depends(get_db),
):
    query = (
        db.query(models.Atleta)
        .options(joinedload(models.Atleta.categoria), joinedload(models.Atleta.centro_treinamento))
    )
    if nome:
        query = query.filter(models.Atleta.nome.ilike(f"%{nome}%"))
    if cpf:
        query = query.filter(models.Atleta.cpf == cpf)

    # O transformer mantém a paginação da biblioteca e customiza cada item da resposta.
    def transformar_atletas(items):
        return [
            schemas.AtletaListItem(
                id=item.id,
                nome=item.nome,
                centro_treinamento=item.centro_treinamento.nome,
                categoria=item.categoria.nome,
            )
            for item in items
        ]

    return paginate(query, params, transformer=transformar_atletas)


@router.get("/{atleta_id}", response_model=schemas.AtletaOut)
def obter_atleta(atleta_id: str, db: Session = Depends(get_db)):
    atleta = (
        db.query(models.Atleta)
        .options(joinedload(models.Atleta.categoria), joinedload(models.Atleta.centro_treinamento))
        .filter(models.Atleta.id == atleta_id)
        .first()
    )
    if not atleta:
        raise HTTPException(status_code=404, detail="Atleta não encontrado.")
    return atleta


@router.delete("/{atleta_id}", status_code=status.HTTP_204_NO_CONTENT)
def excluir_atleta(atleta_id: str, db: Session = Depends(get_db)):
    atleta = db.query(models.Atleta).filter(models.Atleta.id == atleta_id).first()
    if not atleta:
        raise HTTPException(status_code=404, detail="Atleta não encontrado.")
    db.delete(atleta)
    db.commit()
