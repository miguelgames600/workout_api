from pydantic import BaseModel, ConfigDict, Field


class CategoriaCreate(BaseModel):
    nome: str = Field(min_length=1, max_length=40)


class CategoriaOut(CategoriaCreate):
    model_config = ConfigDict(from_attributes=True)
    id: str


class CentroTreinamentoCreate(BaseModel):
    nome: str = Field(min_length=1, max_length=20)
    endereco: str = Field(min_length=1, max_length=60)
    proprietario: str = Field(min_length=1, max_length=30)


class CentroTreinamentoOut(CentroTreinamentoCreate):
    model_config = ConfigDict(from_attributes=True)
    id: str


class AtletaCreate(BaseModel):
    nome: str = Field(min_length=1, max_length=50)
    cpf: str = Field(pattern=r"^\d{11}$", description="CPF com 11 números, sem pontuação")
    idade: int = Field(ge=1, le=120)
    peso: float = Field(gt=0, le=500)
    altura: float = Field(gt=0, le=3)
    sexo: str = Field(pattern=r"^[MF]$")
    centro_treinamento_id: int
    categoria_id: int


class AtletaOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    nome: str
    cpf: str
    idade: int
    peso: float
    altura: float
    sexo: str
    centro_treinamento: CentroTreinamentoOut
    categoria: CategoriaOut


class AtletaListItem(BaseModel):
    id: str
    nome: str
    centro_treinamento: str
    categoria: str
